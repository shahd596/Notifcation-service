const { Kafka } = require('kafkajs');
const { sendNotificationEmail } = require('../services/postmark');

const kafka = new Kafka({
  clientId: process.env.KAFKA_CLIENT_ID,
  brokers: [process.env.KAFKA_BROKER],
});

const consumer = kafka.consumer({ groupId: 'notification-group' });

async function runConsumer() {
  await consumer.connect();
  await consumer.subscribe({ topic: 'ride-events', fromBeginning: false });
  await consumer.subscribe({ topic: 'payment-events', fromBeginning: false });

  await consumer.run({
    eachMessage: async ({ topic, message }) => {
      const payload = JSON.parse(message.value.toString());
      console.log(`[Kafka] Received message on topic ${topic}:`, payload);

      if (topic === 'ride-events') {
        switch (payload.event) {
          case 'ride.booked':
            await sendNotificationEmail({
              to: payload.userEmail,
              templateId: 'ride-booked-template-id',
              templateModel: {
                rideId: payload.rideId,
                driverName: payload.driverName,
                pickupTime: payload.pickupTime,
              },
            });
            break;
          case 'ride.modified':
            await sendNotificationEmail({
              to: payload.userEmail,
              templateId: 'ride-modified-template-id',
              templateModel: {
                rideId: payload.rideId,
                newDestination: payload.newDestination,
              },
            });
            break;
          case 'ride.cancelled':
            await sendNotificationEmail({
              to: payload.userEmail,
              templateId: 'ride-cancelled-template-id',
              templateModel: {
                rideId: payload.rideId,
                reason: payload.reason,
              },
            });
            await sendNotificationEmail({
              to: payload.driverEmail,
              templateId: 'passenger-cancelled-template-id',
              templateModel: {
                passengerName: payload.passengerName,
                rideId: payload.rideId,
              },
            });
            break;
          case 'ride.reminder':
            await sendNotificationEmail({
              to: payload.userEmail,
              templateId: 'ride-reminder-template-id',
              templateModel: {
                rideId: payload.rideId,
                pickupTime: payload.pickupTime,
              },
            });
            break;
        }
      } else if (topic === 'payment-events') {
        switch (payload.event) {
          case 'payment.success':
            await sendNotificationEmail({
              to: payload.userEmail,
              templateId: 'payment-success-template-id',
              templateModel: {
                amount: payload.amount,
                transactionId: payload.transactionId,
              },
            });
            break;
          case 'payment.failed':
            await sendNotificationEmail({
              to: payload.adminEmail,
              templateId: 'payment-failed-template-id',
              templateModel: {
                userEmail: payload.userEmail,
                reason: payload.reason,
              },
            });
            break;
        }
      }
    },
  });
}

module.exports = { runConsumer };
