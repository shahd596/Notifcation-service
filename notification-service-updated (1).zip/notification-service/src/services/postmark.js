const postmark = require('postmark');

const client = new postmark.ServerClient(process.env.POSTMARK_TOKEN);

async function sendNotificationEmail({ to, templateId, templateModel }) {
  try {
    const response = await client.sendEmailWithTemplate({
      From: process.env.FROM_EMAIL,
      To: to,
      TemplateId: templateId,
      TemplateModel: templateModel,
    });

    console.log('[Postmark] Email sent:', response);
  } catch (err) {
    console.error('[Postmark] Failed to send email:', err.message);
  }
}

module.exports = { sendNotificationEmail };
