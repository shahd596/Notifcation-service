function log(message, data) {
  console.log(`[${new Date().toISOString()}] ${message}`, data || '');
}

module.exports = { log };
