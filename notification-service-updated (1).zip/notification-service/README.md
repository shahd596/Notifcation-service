# Notification Service

Microservice for sending email notifications using Postmark and Kafka.
