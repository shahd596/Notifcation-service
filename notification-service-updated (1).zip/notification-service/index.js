require('dotenv').config();
const express = require('express');
const { runConsumer } = require('./src/kafka/consumer');
const app = express();
const PORT = process.env.PORT || 3001;

app.get('/', (req, res) => {
  res.send('Notification Service is running!');
});

runConsumer().catch(console.error);

app.listen(PORT, () => {
  console.log(`Notification Service listening on port ${PORT}`);
});
